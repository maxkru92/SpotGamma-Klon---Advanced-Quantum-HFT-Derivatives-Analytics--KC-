# Directional Exposure Risk Surface

Krupp Capital SPX options flow dashboard.

## Goal

Reimplement the core of SpotGamma **TRACE** as an internal data pipeline + dashboard:

- SPX options **GEX / Delta / Delta Pressure / Charm** heatmap (strike × time)
- **Strike-plot GEX** bars (Call Wall, Put Wall, Gamma Flip, Hedge Wall overlays)
- Candlestick price chart with last close and current price lines
- **Timeline scrubber** with playback across intraday snapshots
- **0DTE toggle**, participant filter (Market Makers / Retail / Firm / All), inverted, metric selector, multi-day forward view

## Stack

- **Frontend**: vanilla HTML + CSS + JavaScript, **ECharts** for visuals
- **Design system**: Krupp Capital institutional dark palette, JetBrains Mono for numeric values, uppercase letter-spaced labels. No emojis in institutional outputs.
- **Data layer**: Python 3.9.6. **Primary**: tastytrade dx. **Fallback with a toggle**: Interactive Brokers via `ib_insync`. Demo data generator for offline development.

## Structure

- `src/` — Python package
- `dashboard/index.html` — TRACE UI shell + ECharts chart engine
- `Makefile` — common targets

## Development

```bash
.venv/bin/pip install -e ".[dev]"
make dev
```

## Data reality

SpotGamma’s TRACE participant-level and intraday inventory estimates are **model-derived from proprietary feeds**. A broker-data pipeline can reproduce the chart forms and transparent public-data estimates (GEX from OI, delta exposure, charm, heatmapped exposure), but it cannot recover dealer inventory or observe every participant. Participant views (MM / Retail / Firm / All) are a UI + modeling layer, not a direct read of dealer books.

## Consent

No network calls, credential reads, or background processes are started by default. Demo mode is the default runtime. Live sources are wired behind explicit config and a UI toggle.
