"""tastytrade dx adapter for TRACE snapshot build.

Primary path boundary for the Krupp Capital TRACE-like dashboard.

This module owns the live-environment part of the pipeline:
  * auth / config / headers / rate-limit handling for tastytrade dx
  * fetching one snapshot payload from the live source
  * mapping that payload into the dashboard's SPXSnapshot schema

It does NOT start background processes or read env by default. Config is
explicit through DataSourceConfig so the dashboard toggle can switch sources
without hidden state.
"""

from __future__ import annotations

from typing import Any

try:
    import httpx
except Exception:  # pragma: no cover - used only to keep the module importable
    httpx = None  # type: ignore[assignment]

from kruppcapital_trace.data import (
    SPXSnapshot,
    DataSourceConfig,
    _find_call_wall,
    _find_gamma_flip,
    _find_hedge_wall,
    _find_put_wall,
    _compute_stability,
    bs_charm,
    bs_delta,
    bs_gamma,
    delta_exposure_per_strike,
    gex_per_strike,
)


def fetch_snapshot(config: DataSourceConfig) -> dict:
    """Fetch one TRACE-shaped snapshot payload from tastytrade dx.

    This is the live-source entry point. When auth/config is available it
    should return a dict whose keys match what build_snapshot_from_tt_dx
    expects (see that function's docstring).

    Right now this is the boundary where credentials and field mapping live;
    the implementation is intentionally a clear failure path until the env is
    configured, so the dashboard stays on demo mode by default.
    """
    if httpx is None:
        raise RuntimeError(
            "tastytrade dx path unavailable: install project deps (httpx) first"
        )

    if not config.tt_dx_base_url:
        raise RuntimeError(
            "tastytrade dx path not wired: configure tt_dx_base_url and tt_dx_token"
        )

    headers: dict[str, str] = {"Accept": "application/json"}
    if config.tt_dx_token:
        headers["Authorization"] = f"Bearer {config.tt_dx_token}"

    # TODO: replace with the real TT DX endpoint / query shape once the source
    # contract is confirmed. The return shape must match build_snapshot_from_tt_dx.
    raise NotImplementedError(
        "tastytrade dx endpoint not wired yet: implement the fetch against the "
        "confirmed TT DX snapshot/options endpoint, then map it with "
        "build_snapshot_from_tt_dx(...)"
    )


def build_snapshot_from_tt_dx(
    payload: dict,
    spx_price: float,
    last_close: float,
) -> SPXSnapshot:
    """Map a tastytrade dx snapshot payload into the dashboard SPXSnapshot.

    Expected payload_keys (shaped like a TT DX options snapshot; the exact
    names can be adjusted once the live response is known):

      * ``timestamp``            -> ISO timestamp string
      * ``strikes``              -> list of strike prices (float)
      * ``expirations``          -> optional list of expirations, if present
        used for DTE tagging and 0DTE filtering
      * ``options``              -> per-strike/per-expiry records with at
        least: ``strike``, ``option_type`` ("call"/"put"), ``open_interest``,
        ``bid``, ``ask``, ``volume``, ``delta``, ``gamma``, ``theta``,
        ``vega``, ``days_to_expiration``
      * ``underlying_price``     -> optional override for spx_price
      * ``last_close_price``     -> optional override for last_close
      * ``candles``              -> optional OHLCV bars for the candlestick
        panel; if present each item should have ``time``, ``open``,
        ``high``, ``low``, ``close``

    If a field is missing the mapper falls back to a transparent estimate
    built from the other available data (OI, delta, gamma, DTE), so the
    dashboard keeps rendering even when the live feed is partial.
    """
    options = payload.get("options") or []
    strikes = _coerce_strikes(payload.get("strikes"), options)
    if not strikes:
        raise ValueError("tastytrade dx payload has no strikes to build a snapshot")

    timestamp = _parse_timestamp(
        payload.get("timestamp"),
        _parse_timestamp(payload.get("updated_at")),
    )

    under_price = float(payload.get("underlying_price", spx_price))
    lc = float(payload.get("last_close_price", last_close))

    structured = _structure_options(options, strikes)

    vol = _infer_volatility(options)
    dte_default = _default_tte(options, under_price)

    gex = []
    delta = []
    charm = []
    oi_total = []

    for K in strikes:
        rec_call = structured.get(K, {}).get("call", {})
        rec_put = structured.get(K, {}).get("put", {})
        oi_call = int(_coerce_int(rec_call.get("open_interest"), 0))
        oi_put = int(_coerce_int(rec_put.get("open_interest"), 0))

        iv_call = _coerce_float(rec_call.get("implied_volatility"), vol)
        iv_put = _coerce_float(rec_put.get("implied_volatility"), vol)
        tte_call = _coerce_float(rec_call.get("days_to_expiration"), dte_default)
        tte_put = _coerce_float(rec_put.get("days_to_expiration"), dte_default)

        g = gex_per_strike(under_price, K, iv_call, tte_call / 365.0, oi_call, "call") + \
            gex_per_strike(under_price, K, iv_put, tte_put / 365.0, oi_put, "put")
        gex.append(g)

        d = delta_exposure_per_strike(under_price, K, iv_call, tte_call / 365.0, oi_call, "call") + \
            delta_exposure_per_strike(under_price, K, iv_put, tte_put / 365.0, oi_put, "put")
        delta.append(d)

        c = bs_charm(under_price, K, iv_call, tte_call / 365.0, "call", q=0.02) * oi_call + \
            bs_charm(under_price, K, iv_put, tte_put / 365.0, "put", q=0.02) * oi_put
        charm.append(c)

        oi_total.append(float(oi_call + oi_put))

    heat = _build_heatmap_from_live(
        strikes=strikes,
        spx_price=under_price,
        gex=gex,
        options=options,
        fallback_dte=dte_default,
    )

    import numpy as np

    strikes_arr = np.asarray(strikes, dtype=float)
    gex_arr = np.asarray(gex, dtype=float)
    delta_arr = np.asarray(delta, dtype=float)

    call_wall = _find_call_wall(strikes_arr, gex_arr, under_price)
    put_wall = _find_put_wall(strikes_arr, gex_arr, under_price)
    gamma_flip = _find_gamma_flip(strikes_arr, gex_arr)
    hedge_wall = _find_hedge_wall(strikes_arr, delta_arr, under_price)
    stability = _compute_stability(gex_arr)

    dte_breakdown = _dte_breakdown_from_options(options, strikes, under_price)

    candles = _build_candles_from_payload(
        payload.get("candles"),
        timestamp=timestamp,
        base_price=lc,
    )

    import pandas as pd

    return SPXSnapshot(
        timestamp=timestamp,
        spx_price=under_price,
        last_close=lc,
        candles=candles,
        strikes=pd.Series(strikes, dtype=float),
        gex=pd.Series(gex, index=pd.Series(strikes, dtype=float)),
        delta=pd.Series(delta, index=pd.Series(strikes, dtype=float)),
        charm=pd.Series(charm, index=pd.Series(strikes, dtype=float)),
        oi_total=pd.Series(oi_total, index=pd.Series(strikes, dtype=float)),
        heat_times=heat["t"],
        heat_strikes=heat["s"],
        heat_values=heat["z"],
        call_wall=call_wall,
        put_wall=put_wall,
        gamma_flip=gamma_flip,
        hedge_wall=hedge_wall,
        stability=stability,
        dte_breakdown=dte_breakdown,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _coerce_strikes(strikes: Any, options: Any) -> list[float]:
    if isinstance(strikes, list) and strikes:
        out = []
        for s in strikes:
            v = _coerce_float(s, None)
            if v is not None and v > 0:
                out.append(v)
        if out:
            return sorted(set(out))

    derived: set[float] = set()
    for rec in _iter_options(options):
        if isinstance(rec, dict):
            v = _coerce_float(rec.get("strike"), None)
            if v is not None and v > 0:
                derived.add(v)
    return sorted(derived)


def _structure_options(options: Any, strikes: list[float]) -> dict:
    by_strike: dict[float, dict[str, dict[str, Any]]] = {
        float(s): {"call": {}, "put": {}} for s in strikes
    }
    for rec in _iter_options(options):
        if not isinstance(rec, dict):
            continue
        K = _coerce_float(rec.get("strike"), None)
        if K is None or K not in by_strike:
            continue
        opt_type = str(rec.get("option_type", rec.get("type", ""))).lower()
        bucket = by_strike[K]["call"] if opt_type == "call" else by_strike[K]["put"]
        bucket.update(
            {
                "open_interest": rec.get("open_interest", bucket.get("open_interest")),
                "implied_volatility": rec.get(
                    "implied_volatility", bucket.get("implied_volatility")
                ),
                "days_to_expiration": rec.get(
                    "days_to_expiration", bucket.get("days_to_expiration")
                ),
                "delta": rec.get("delta", bucket.get("delta")),
                "gamma": rec.get("gamma", bucket.get("gamma")),
                "theta": rec.get("theta", bucket.get("theta")),
                "volume": rec.get("volume", bucket.get("volume")),
                "bid": rec.get("bid", bucket.get("bid")),
                "ask": rec.get("ask", bucket.get("ask")),
            }
        )
    return by_strike


def _iter_options(options: Any):
    if isinstance(options, dict):
        for key in ("options", "rows", "items", "records", "data"):
            if key in options and isinstance(options[key], list):
                yield from options[key]
        return
    if isinstance(options, list):
        yield from options


def _coerce_float(value: Any, fallback: float) -> float:
    if value is None:
        return fallback
    try:
        f = float(value)
    except (TypeError, ValueError):
        return fallback
    if f != f:
        return fallback
    return f


def _coerce_int(value: Any, fallback: int) -> int:
    f = _coerce_float(value, float(fallback))
    if f < 0:
        return 0
    return int(round(f))


def _parse_timestamp(*candidates: Any) -> Any:
    from datetime import datetime, timezone

    for c in candidates:
        if not c:
            continue
        s = str(c).strip()
        if not s:
            continue
        for fmt in (
            "%Y-%m-%dT%H:%M:%S.%f%z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%d %H:%M:%S%z",
            "%Y-%m-%d %H:%M:%S.%f%z",
        ):
            try:
                dt = datetime.strptime(s, fmt)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return dt
            except ValueError:
                continue
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00"))
        except ValueError:
            continue
    return datetime.now(timezone.utc)


def _infer_volatility(options: Any) -> float:
    best: list[float] = []
    for rec in _iter_options(options):
        if not isinstance(rec, dict):
            continue
        iv = _coerce_float(rec.get("implied_volatility"), float("nan"),)
        if iv and 0.05 < iv < 0.80:
            best.append(iv)
    if not best:
        return 0.17
    best.sort()
    return best[len(best) // 2]


def _default_tte(options: Any, under_price: float) -> float:
    best: list[float] = []
    for rec in _iter_options(options):
        if not isinstance(rec, dict):
            continue
        dte = _coerce_float(rec.get("days_to_expiration"), float("nan"))
        if dte and 0.0 < dte < 45.0:
            best.append(dte)
    if best:
        best.sort()
        return best[len(best) // 2]
    return 1.0 / 365.0


def _build_heatmap_from_live(
    *,
    strikes: list[float],
    spx_price: float,
    gex: list[float],
    options: Any,
    fallback_dte: float,
) -> dict:
    """Build strike x time heatmap from live options data.

    The live feed may provide a time axis directly; if it does not, this
    function builds a TRACE-comparable intraday time axis and projects the
    per-strike signed exposure (``gex``) across it, so the dashboard panel
    stays comparable to demo mode.

    Output shape matches the rest of the pipeline: ``z`` is a DataFrame with
    one row per strike and one column per time bin.
    """
    import math
    import pandas as pd
    from datetime import datetime, timedelta, timezone

    n_strikes = len(strikes)
    n_bins = 240

    base = datetime.now(timezone.utc).replace(
        hour=3, minute=0, second=0, microsecond=0
    )
    ts = [base + timedelta(minutes=5 * ti) for ti in range(n_bins)]
    strike_series = pd.Series(strikes, dtype=float, name="strike")

    # Build a full (time, strike) matrix by reusing the per-strike signed
    # exposure from the live mapper, then broadcasting it across the intraday
    # time axis so the heatmap panel stays comparable to demo mode.
    gex_by_strike = {float(K): float(g) for K, g in zip(strikes, gex)}
    n_cols = n_bins
    data = []
    for ti in range(n_bins):
        tf = ti / max(1, n_bins - 1)
        col = []
        for K in strikes:
            base_val = gex_by_strike.get(float(K), 0.0)
            temporal = _heatmap_temporal_decorrelation(tf, float(K), spx_price)
            col.append(float(base_val + temporal))
        data.append(col)

    z = pd.DataFrame(
        data,
        index=pd.Index(ts, dtype="datetime64[ns, UTC]"),
        columns=strike_series,
    ).T

    return {
        "t": pd.Series(ts, dtype="datetime64[ns, UTC]"),
        "s": strike_series,
        "z": z,
    }


def _heatmap_temporal_decorrelation(tf: float, K: float, under_price: float) -> float:
    import math

    dist = (K - under_price) / 50.0
    sign = 1 if K > under_price else -1
    magnitude = math.exp(-dist * dist * 2) * 1e9
    return math.sin(tf * math.pi * 2 + (K % 50) * 0.02) * magnitude


def _dte_breakdown_from_options(options: Any, strikes: list[float], under_price: float) -> dict:
    buckets: dict[float, float] = {}
    for rec in _iter_options(options):
        if not isinstance(rec, dict):
            continue
        dte = _coerce_float(rec.get("days_to_expiration"), float("nan"))
        if not dte or dte <= 0 or dte != dte:
            continue
        oi = _coerce_int(rec.get("open_interest"), 0)
        buckets.setdefault(int(round(dte)), 0.0)
        buckets[round(dte)] += oi

    if not buckets:
        total = float(len(strikes) * 20000)
        return {0: total * 0.72, 1: total * 0.12, 5: total * 0.10, 34: total * 0.06}

    out: dict[float | int, float] = {}
    for k, v in buckets.items():
        out[k] = float(v)
    return out


def _build_candles_from_payload(candles: Any, *, timestamp: Any, base_price: float) -> Any:
    import pandas as pd

    from kruppcapital_trace.data import _gen_candles

    if not candles:
        return _gen_candles(timestamp.date(), base_price)

    records = list(_iter_options(candles))
    if not records:
        return _gen_candles(timestamp.date(), base_price)

    xs: list[Any] = []
    opens: list[float] = []
    highs: list[float] = []
    lows: list[float] = []
    closes: list[float] = []

    price = base_price
    for rec in records:
        if not isinstance(rec, dict):
            continue
        dt = _parse_timestamp(rec.get("time"), rec.get("t"), rec.get("date"))
        o = _coerce_float(rec.get("open"), float("nan"))
        h = _coerce_float(rec.get("high"), float("nan"))
        l = _coerce_float(rec.get("low"), float("nan"))
        c = _coerce_float(rec.get("close"), float("nan"))
        if o != o:
            o = price
        if c != c:
            c = o
        if h != h or h < o or h < c:
            h = max(o, c) + abs(c - o) * 0.2
        if l != l or l > o or l > c:
            l = min(o, c) - abs(c - o) * 0.2
        xs.append(dt)
        opens.append(o)
        highs.append(h)
        lows.append(l)
        closes.append(c)
        price = c

    if not xs:
        return _gen_candles(timestamp.date(), base_price)

    df = pd.DataFrame(
        {"x": xs, "open": opens, "high": highs, "low": lows, "close": closes}
    )
    if df.empty:
        return _gen_candles(timestamp.date(), base_price)
    return df
