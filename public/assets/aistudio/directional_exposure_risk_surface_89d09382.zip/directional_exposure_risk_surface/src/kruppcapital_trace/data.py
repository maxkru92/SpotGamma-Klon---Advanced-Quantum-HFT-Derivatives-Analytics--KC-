"""
Krupp Capital TRACE-like dashboard — data layer.

Primary data source: tastytrade dx.
Fallback (toggleable): Interactive Brokers via ib_insync.
Offline default: synthetic demo data generator.

SpotGamma TRACE participant-level and intraday inventory estimates are
model-derived from proprietary feeds. This layer reproduces chart forms and
transparent public-data estimates (GEX from OI, delta exposure, charm,
heatmapped exposure). Participant views are a modeling/UI layer, not a direct
read of dealer books.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Literal, Sequence

import numpy as np
import pandas as pd

MetricType = Literal["gex", "delta", "charm", "oi"]
ParticipantView = Literal["mm", "retail", "firm", "all"]
LenseType = Literal["delta_pressure", "gex", "charm", "vanna", "hiro"]


class SPXSnapshot:
    """One intraday snapshot of SPX options-derived exposures."""

    __slots__ = (
        "timestamp", "spx_price", "last_close", "candles", "strikes",
        "gex", "delta", "charm", "oi_total",
        "heat_times", "heat_strikes", "heat_values",
        "call_wall", "put_wall", "gamma_flip", "hedge_wall",
        "stability", "dte_breakdown",
    )

    def __init__(
        self,
        *,
        timestamp: datetime,
        spx_price: float,
        last_close: float,
        candles: pd.DataFrame,
        strikes: pd.Series,
        gex: pd.Series,
        delta: pd.Series,
        charm: pd.Series,
        oi_total: pd.Series,
        heat_times: pd.Series,
        heat_strikes: pd.Series,
        heat_values: pd.DataFrame,
        call_wall: float | None = None,
        put_wall: float | None = None,
        gamma_flip: float | None = None,
        hedge_wall: float | None = None,
        stability: float = 0.0,
        dte_breakdown: dict | None = None,
    ) -> None:
        object.__setattr__(self, "timestamp", timestamp)
        object.__setattr__(self, "spx_price", spx_price)
        object.__setattr__(self, "last_close", last_close)
        object.__setattr__(self, "candles", candles)
        object.__setattr__(self, "strikes", strikes)
        object.__setattr__(self, "gex", gex)
        object.__setattr__(self, "delta", delta)
        object.__setattr__(self, "charm", charm)
        object.__setattr__(self, "oi_total", oi_total)
        object.__setattr__(self, "heat_times", heat_times)
        object.__setattr__(self, "heat_strikes", heat_strikes)
        object.__setattr__(self, "heat_values", heat_values)
        object.__setattr__(self, "call_wall", call_wall)
        object.__setattr__(self, "put_wall", put_wall)
        object.__setattr__(self, "gamma_flip", gamma_flip)
        object.__setattr__(self, "hedge_wall", hedge_wall)
        object.__setattr__(self, "stability", stability)
        object.__setattr__(self, "dte_breakdown", dict(dte_breakdown or {}))


class DataSourceConfig:
    """Which live source is active, and how to reach it."""

    __slots__ = ("mode", "tt_dx_base_url", "tt_dx_token", "ib_host", "ib_port", "ib_client_id", "ib_use_paper")

    def __init__(
        self,
        *,
        mode: str = "demo",
        tt_dx_base_url: str = "",
        tt_dx_token: str = "",
        ib_host: str = "127.0.0.1",
        ib_port: int = 7497,
        ib_client_id: int = 100,
        ib_use_paper: bool = True,
    ) -> None:
        object.__setattr__(self, "mode", mode)
        object.__setattr__(self, "tt_dx_base_url", tt_dx_base_url)
        object.__setattr__(self, "tt_dx_token", tt_dx_token)
        object.__setattr__(self, "ib_host", ib_host)
        object.__setattr__(self, "ib_port", ib_port)
        object.__setattr__(self, "ib_client_id", ib_client_id)
        object.__setattr__(self, "ib_use_paper", ib_use_paper)


# ---------------------------------------------------------------------------
# Greeks / exposure math
# ---------------------------------------------------------------------------

def bs_gamma(S: float, K: float, vol: float, T: float, r: float = 0.05, q: float = 0.02) -> float:
    """Black-Scholes gamma (non-dividend-adjusted sign conventions kept simple)."""
    if T <= 0.0 or vol <= 0.0 or S <= 0.0 or K <= 0.0:
        return 0.0
    try:
        d1 = (math.log(S / K) + (r - q + 0.5 * vol**2) * T) / (vol * math.sqrt(T))
        return math.exp(-q * T) * _norm_pdf(d1) / (S * vol * math.sqrt(T))
    except (ZeroDivisionError, OverflowError, ValueError):
        return 0.0


def bs_delta(S: float, K: float, vol: float, T: float, option_type: str = "call", r: float = 0.05, q: float = 0.02) -> float:
    if T <= 0.0 or vol <= 0.0 or S <= 0.0 or K <= 0.0:
        return 0.0
    try:
        d1 = (math.log(S / K) + (r - q + 0.5 * vol**2) * T) / (vol * math.sqrt(T))
        cdf = _norm_cdf(d1)
        if option_type.lower() == "call":
            return math.exp(-q * T) * cdf
        return -math.exp(-q * T) * _norm_cdf(-d1)
    except (ZeroDivisionError, OverflowError, ValueError):
        return 0.0


def bs_charm(S: float, K: float, vol: float, T: float, option_type: str = "call", r: float = 0.05, q: float = 0.02) -> float:
    """Charm = dDelta/dT (per year). Approximate closed form."""
    if T <= 0.0 or vol <= 0.0 or S <= 0.0 or K <= 0.0:
        return 0.0
    try:
        sqrtT = math.sqrt(T)
        d1 = (math.log(S / K) + (r - q + 0.5 * vol**2) * T) / (vol * sqrtT)
        pdf = _norm_pdf(d1)
        if option_type.lower() == "call":
            term1 = -q * math.exp(-q * T) * _norm_cdf(d1)
            term2 = -math.exp(-q * T) * pdf * (2 * (r - q) * T - vol**2 * T) / (2 * T * S * vol * sqrtT)
            return term1 + term2
        term1 = q * math.exp(-q * T) * _norm_cdf(-d1)
        term2 = math.exp(-q * T) * pdf * (2 * (r - q) * T - vol**2 * T) / (2 * T * S * vol * sqrtT)
        return term1 + term2
    except (ZeroDivisionError, OverflowError, ValueError):
        return 0.0


def gex_per_strike(S: float, K: float, vol: float, T: float, oi: int, option_type: str = "call", contract_multiplier: int = 100) -> float:
    """Gamma exposure per 1% underlying move (\\$ notional)."""
    gamma = bs_gamma(S, K, vol, T)
    notional = gamma * oi * contract_multiplier * S * S * 0.01
    if option_type.lower() == "put":
        notional = -notional
    return notional


def delta_exposure_per_strike(S: float, K: float, vol: float, T: float, oi: int, option_type: str = "call", contract_multiplier: int = 100) -> float:
    delta = bs_delta(S, K, vol, T, option_type)
    notional = delta * oi * contract_multiplier * S
    if option_type.lower() == "put":
        notional = -notional
    return notional


# ---------------------------------------------------------------------------
# Demo data generator (offline default)
# ---------------------------------------------------------------------------

def generate_demo_snapshot(
    timestamp: datetime | None = None,
    spx_price: float = 7127.0,
    last_close: float = 7126.06,
    strike_min: int = 7050,
    strike_max: int = 7195,
    strike_step: int = 5,
    n_time_bins: int = 240,
) -> SPXSnapshot:
    """Generate a realistic TRACE-shaped demo snapshot for offline development."""
    if timestamp is None:
        timestamp = datetime.now(timezone.utc)

    strikes = pd.Series(range(strike_min, strike_max + strike_step, strike_step), dtype=float)
    n_strikes = len(strikes)

    volatility = 0.16
    dte_today = 1.0 / 365.0

    rng = np.random.default_rng(int(timestamp.timestamp()) % 2**31)

    # Per-strike OI: ATM peak, smile shape
    atm_idx = int(np.argmin(np.abs(strikes.values - spx_price)))
    call_oi = np.maximum(800, 22000 * np.exp(-((np.arange(n_strikes) - atm_idx) / 6.0) ** 2))
    put_oi = np.maximum(800, 20000 * np.exp(-((np.arange(n_strikes) - atm_idx + 2) / 6.0) ** 2))
    call_oi = call_oi.astype(int)
    put_oi = put_oi.astype(int)

    # IV smile
    call_iv = volatility + 0.05 * np.abs(np.arange(n_strikes) - atm_idx) / (n_strikes / 2.0)
    put_iv = call_iv + rng.normal(0, 0.01, n_strikes)
    call_iv = np.clip(call_iv, 0.08, 0.45)
    put_iv = np.clip(put_iv, 0.08, 0.45)

    # GEX: sign alternates by strike for demo texture, magnitude ATM-focussed
    gex_call = np.array([gex_per_strike(spx_price, K, iv, dte_today, oi, "call") for K, iv, oi in zip(strikes, call_iv, call_oi)])
    gex_put = np.array([gex_per_strike(spx_price, K, iv, dte_today, oi, "put") for K, iv, oi in zip(strikes, put_iv, put_oi)])
    gex = gex_call + gex_put

    # Delta exposure
    delta_call = np.array([delta_exposure_per_strike(spx_price, K, iv, dte_today, oi, "call") for K, iv, oi in zip(strikes, call_iv, call_oi)])
    delta_put = np.array([delta_exposure_per_strike(spx_price, K, iv, dte_today, oi, "put") for K, iv, oi in zip(strikes, put_iv, put_oi)])
    delta = delta_call + delta_put

    # Charm (dollar notional by strike, sign by option type)
    charm = np.array(
        [bs_charm(spx_price, K, iv, dte_today, "call") * oi + bs_charm(spx_price, K, iv, dte_today, "put") * oi
         for K, iv, oi in zip(strikes, call_iv, call_oi)]
    )

    # OI total
    oi_total = call_oi + put_oi

    # Candles: 15m from 04:00 to 22:00 UTC
    candles_df = _gen_candles(timestamp.date(), spx_price - 5.0)

    # Heatmap: strike x time, delta pressure
    heat = _gen_heatmap(strikes.values, spx_price, n_time_bins, timestamp.date())

    # Key levels
    call_wall = _find_call_wall(strikes.values, gex, spx_price)
    put_wall = _find_put_wall(strikes.values, gex, spx_price)
    gamma_flip = _find_gamma_flip(strikes.values, gex)
    hedge_wall = _find_hedge_wall(strikes.values, delta, spx_price)

    # Stability
    stability = _compute_stability(gex)

    # DTE breakdown (demo: mostly 0DTE)
    dte_breakdown = {0: float(oi_total.sum() * 0.72), 1: float(oi_total.sum() * 0.12), 5: float(oi_total.sum() * 0.10), 34: float(oi_total.sum() * 0.06)}

    return SPXSnapshot(
        timestamp=timestamp,
        spx_price=spx_price,
        last_close=last_close,
        candles=candles_df,
        strikes=strikes,
        gex=pd.Series(gex, index=strikes),
        delta=pd.Series(delta, index=strikes),
        charm=pd.Series(charm, index=strikes),
        oi_total=pd.Series(oi_total.astype(float), index=strikes),
        heat_times=heat["t"],
        heat_strikes=heat["s"],
        heat_values=heat["z"],
        call_wall=call_wall,
        put_wall=put_wall,
        gamma_flip=gamma_flip,
        hedge_wall=hedge_wall,
        stability=stability,
        dte_breakdown=dte_breakdown,
    )


def _gen_candles(date: date, base_price: float):
    x, o, h, l, c = [], [], [], [], []
    price = base_price
    for hour in range(4, 22):
        for minute in (0, 15, 30, 45):
            dt = datetime.combine(date, datetime.min.time()).replace(hour=hour, minute=minute, tzinfo=timezone.utc)
            open_ = price
            move = np.random.default_rng(int(dt.timestamp()) % 2**31).normal(0, 1.0)
            close_ = open_ + move
            high_ = max(open_, close_) + np.random.default_rng(int(dt.timestamp()) % 2**31).uniform(0.3, 1.6)
            low_ = min(open_, close_) - np.random.default_rng(int(dt.timestamp()) % 2**31).uniform(0.3, 1.6)
            x.append(dt)
            o.append(open_)
            h.append(high_)
            l.append(low_)
            c.append(close_)
            price = close_
    return pd.DataFrame({"x": x, "open": o, "high": h, "low": l, "close": c})


def _gen_heatmap(strikes, spx_price, n_time_bins, date):
    base = datetime.combine(date, datetime.min.time()).replace(hour=3, tzinfo=timezone.utc)
    n_str = len(strikes)
    ts = []
    ys = []
    zs = []
    for ti in range(n_time_bins):
        t = base + timedelta(minutes=5 * ti)
        row = []
        for si in range(n_str):
            s = strikes[si]
            dist = (s - spx_price) / 50.0
            tf = ti / n_time_bins
            sign = 1 if s > spx_price else -1
            magnitude = math.exp(-dist * dist * 2) * 3e9
            noise = np.random.default_rng(int(t.timestamp()) % 2**31).normal(0, 5e8)
            temporal = math.sin(tf * math.pi * 2 + si * 0.3) * 1e9
            ys.append(s)
            row.append(sign * magnitude + temporal + noise)
            if si == 0:
                ts.append(t)
        zs.append(row)
    z = np.array(zs)  # (n_time_bins, n_str)
    return {
        "t": pd.Series(ts),
        "s": pd.Series(list(strikes), dtype=float),
        "z": pd.DataFrame(z.T, index=pd.Series(list(strikes), dtype=float), columns=pd.Series(ts)),
    }


def _norm_pdf(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def _norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2)))


def _find_call_wall(strikes, gex, price):
    above = [(s, g) for s, g in zip(strikes, gex) if s > price]
    if not above:
        return None
    return max(above, key=lambda t: t[1])[0]


def _find_put_wall(strikes, gex, price):
    below = [(s, g) for s, g in zip(strikes, gex) if s < price]
    if not below:
        return None
    return min(below, key=lambda t: t[1])[0]


def _find_gamma_flip(strikes, gex):
    signs = np.sign(gex)
    for i in range(1, len(signs)):
        if signs[i - 1] < 0 and signs[i] >= 0:
            a, b = gex[i - 1], gex[i]
            sa, sb = strikes[i - 1], strikes[i]
            if b != a:
                return float(sb - (sb - sa) * b / (b - a))
            return float(sa)
    return None


def _find_hedge_wall(strikes, delta, price):
    """Heuristic: largest delta notional strike adjacent to price."""
    idx = int(np.argmin(np.abs(strikes - price)))
    window = slice(max(0, idx - 3), min(len(strikes), idx + 4))
    return float(strikes[window][np.argmax(np.abs(delta[window]))])


def _compute_stability(gex):
    """Simple heuristic: fraction of strikes near zero gamma."""
    arr = np.clip(np.abs(gex), 0, 1e10)
    if arr.size == 0:
        return 50.0
    maxg = arr.max()
    if maxg == 0:
        return 100.0
    near_zero = np.mean(arr < 0.05 * maxg)
    return float(np.clip(100.0 - near_zero * 100.0, 0, 100))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_trace_bundle(config: DataSourceConfig = DataSourceConfig()) -> SPXSnapshot:
    """Entry point for the dashboard data fetch. Returns one SPXSnapshot.

    Default is demo mode. Live modes are wired behind config injection and
    are currently stubs pending credentials/live auth.
    """
    if config.mode == "demo":
        return generate_demo_snapshot()
    if config.mode == "tastytrade":
        return _fetch_tastytrade_dx(config)
    if config.mode == "ibkr":
        return _fetch_ibkr(config)
    raise ValueError(f"Unsupported data source mode: {config.mode}")


def _fetch_tastytrade_dx(config: DataSourceConfig) -> SPXSnapshot:
    """Primary path: tastytrade dx. Stub pending live auth/config."""
    raise RuntimeError("tastytrade dx path not wired: configure tt_dx_base_url and tt_dx_token")


def _fetch_ibkr(config: DataSourceConfig) -> SPXSnapshot:
    """Fallback path: Interactive Brokers via ib_insync. Stub pending live TWS/Gateway."""
    raise RuntimeError("IBKR path not wired: start TWS/Gateway and configure ib_host/ib_port")


if __name__ == "__main__":
    snap = generate_demo_snapshot()
    print("SPX:", snap.spx_price)
    print("Call Wall:", snap.call_wall)
    print("Put Wall:", snap.put_wall)
    print("Gamma Flip:", snap.gamma_flip)
    print("Hedge Wall:", snap.hedge_wall)
    print("Stability:", snap.stability)
    print("Strikes:", len(snap.strikes))
    print("Heatmap frames:", len(snap.heat_times))
