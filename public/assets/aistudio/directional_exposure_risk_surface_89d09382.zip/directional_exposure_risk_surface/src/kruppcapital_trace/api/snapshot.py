#!/usr/bin/env python3
"""Dev helper: emit current TRACE snapshot as JSON.

In dev, run `make snapshot` and copy output into dashboard/data/snapshot.json,
or serve src/ as a small static root.

This keeps the dashboard offline-friendly: the HTML includes an inline demo fallback,
and the live path is wired behind the same shape.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


def _find_src_root() -> Path:
    """Locate the project src/ directory from wherever this script is invoked."""
    root = Path(__file__).resolve()
    # This file lives at: <project>/src/kruppcapital_trace/api/snapshot.py
    candidate = root.parents[2] / "src"
    if (candidate / "kruppcapital_trace" / "data.py").exists():
        return candidate
    # Fallback: walk up from cwd looking for src/kruppcapital_trace/data.py
    for parent in [Path.cwd(), *Path.cwd().resolve().parents]:
        probe = parent / "src" / "kruppcapital_trace" / "data.py"
        if probe.exists():
            return parent / "src"
    raise SystemExit("Could not locate project src/ containing kruppcapital_trace.data")


def main() -> None:
    src_root = _find_src_root()
    if str(src_root) not in sys.path:
        sys.path.insert(0, str(src_root))

    from kruppcapital_trace.data import build_trace_bundle, DataSourceConfig

    cfg = DataSourceConfig()
    snap = build_trace_bundle(cfg)
    payload = {
        "timestamp": snap.timestamp.isoformat(),
        "spx_price": snap.spx_price,
        "last_close": snap.last_close,
        "strikes": [float(x) for x in snap.strikes],
        "candles": {
            "x": [d.isoformat() for d in snap.candles["x"]],
            "open": [float(v) for v in snap.candles["open"]],
            "high": [float(v) for v in snap.candles["high"]],
            "low": [float(v) for v in snap.candles["low"]],
            "close": [float(v) for v in snap.candles["close"]],
        },
        "heatTimes": [d.isoformat() for d in snap.heat_times],
        "heatValues": snap.heat_values.round(4).values.tolist(),
        "gex": [float(v) for v in snap.gex],
        "delta": [float(v) for v in snap.delta],
        "charm": [float(v) for v in snap.charm],
        "oi_total": [float(v) for v in snap.oi_total],
        "keyLevels": {
            "callWall": snap.call_wall,
            "putWall": snap.put_wall,
            "keyGamma": snap.gamma_flip,
            "hedgeWall": snap.hedge_wall,
        },
        "stability": snap.stability,
        "dte_breakdown": snap.dte_breakdown,
    }
    text = json.dumps(payload)
    print(text)

    project_root = src_root.parent
    target = project_root / "dashboard" / "data" / "snapshot.json"
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    except OSError:
        pass


if __name__ == "__main__":
    main()
